// server.js
// Simple Express server to test GET and POST requests using Postman

const express = require('express');
const app = express();

// Middleware to parse JSON data from POST requests
app.use(express.json());

// Basic GET route
app.get('/', (req, res) => {
  res.status(200).send('GET request successful! ✅');
});

// POST route to receive data
app.post('/submit', (req, res) => {
  const data = req.body;
  res.status(201).json({
    message: 'POST request received successfully!',
    receivedData: data
  });
});

// Invalid route test
app.use((req, res) => {
  res.status(404).send('404 Not Found ❌');
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
